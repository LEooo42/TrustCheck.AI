/* ---------- config ---------- */

document.getElementById("year").textContent = new Date().getFullYear();



const API_BASE = "https://trustcheck-ai.onrender.com";
const ANALYZE_ENDPOINT = `${API_BASE}/v1/analyze`;
const RATE_STATUS_ENDPOINT = `${API_BASE}/v1/rate-status`;
const STATS_ENDPOINT      = `${API_BASE}/v1/stats`;
const BOOKMARKS_ENDPOINT  = `${API_BASE}/v1/bookmarks`;

const MAX_HISTORY = 50;
const REQUIRE_IMAGE = false; // image not required in URL mode 

/* ---------- element refs ---------- */

const dropArea = document.getElementById("drop-area");
const fileInput = document.getElementById("fileInput");
const fileNameDisplay = document.getElementById("fileName");
const deleteBtn = document.getElementById("delete-btn");
const previewArea = document.getElementById("previewArea");

const textInput = document.getElementById("textInput");
const platformSelect = document.getElementById("platformSelect");
const analyzeBtn = document.getElementById("analyzeButton");
const loadingDots = document.getElementById("loadingDots");

// Optional (only if exists in your HTML)
const imagePreview = document.getElementById("imagePreview");

// Input mode
const urlInput = document.getElementById("urlInput");
let inputMode = "upload"; // "upload" | "url"

/* ---------- utils ---------- */

/*
Function to safely set files into a file input using DataTransfer
Parameters:
- input: HTMLInputElement
- files: FileList
Returns:
- None
*/
function setInputFiles(input, files) {
  const dt = new DataTransfer();
  Array.from(files).forEach(f => dt.items.add(f));
  input.files = dt.files;
}

/*
Function to fetch with timeout using AbortController
Parameters:
- url: string
- options: object
- timeoutMs: number
Returns:
- Promise<Response>
*/
async function fetchWithTimeout(url, options, timeoutMs = 30000) {
  const controller = new AbortController();
  const t = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(t);
  }
}

/*
Function to sanitize an array of strings
Parameters:
- list: any
Returns:
- string[]
*/
function sanitizeList(list) {
  if (!Array.isArray(list)) return [];
  return list
    .map(s => String(s).trim())
    .filter(Boolean)
    .filter(s => !/^(-\s*)?none$/i.test(s));
}

/*
Function to show a friendly error to the user
Parameters:
- message: string
Returns:
- None
*/

/* ---------- input mode switching (upload / url) ---------- */

document.getElementById("modeUploadBtn").addEventListener("click", () => setInputMode("upload"));
document.getElementById("modeUrlBtn").addEventListener("click",   () => setInputMode("url"));

function setInputMode(mode) {
  inputMode = mode;

  document.getElementById("modeUploadBtn").classList.toggle("mode-btn--active", mode === "upload");
  document.getElementById("modeUrlBtn").classList.toggle("mode-btn--active",   mode === "url");

  document.getElementById("inputModeUpload").style.display = mode === "upload" ? "" : "none";
  document.getElementById("inputModeUrl").style.display   = mode === "url"    ? "" : "none";

  validateForm();
}

function isValidUrl(str) {
  try {
    const u = new URL(str.trim());
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

if (urlInput) urlInput.addEventListener("input", validateForm);

function showError(message) {
  console.error(message);
  alert(message);
}

/*
Function to build a bounded history list in localStorage
Parameters:
- item: object
Returns:
- None
*/
function pushHistory(item) {
  const storedHistory = JSON.parse(localStorage.getItem("adHistory")) || [];
  storedHistory.unshift(item);
  localStorage.setItem("adHistory", JSON.stringify(storedHistory.slice(0, MAX_HISTORY)));
}


/* ---------- rate limit indicator ---------- */

/*
Function to fetch and render the rate limit status bar
Parameters: None
Returns: None
*/
async function updateRateIndicator() {
  const fill  = document.getElementById("rateBarFill");
  const label = document.getElementById("rateLabel");
  if (!fill || !label) return;

  try {
    const res  = await fetch(RATE_STATUS_ENDPOINT);
    if (!res.ok) throw new Error("status error");
    const data = await res.json();

    const { limit, remaining } = data;
    const pct = Math.round((remaining / limit) * 100);

    fill.style.width = pct + "%";
    fill.classList.remove("rate-indicator__fill--warn", "rate-indicator__fill--low");
    if (pct <= 20)      fill.classList.add("rate-indicator__fill--low");
    else if (pct <= 50) fill.classList.add("rate-indicator__fill--warn");

    label.textContent = `${remaining} / ${limit} analyses left`;
  } catch {
    const label = document.getElementById("rateLabel");
    if (label) label.textContent = "";
  }
}


/* ---------- file list + preview ---------- */

/*
Function to update the display with the selected file names
Parameters:
- files: FileList | File[]
Returns:
- None
*/
function updateFileList(files) {
  const arr = Array.from(files || []);
  if (arr.length === 0) {
    fileNameDisplay.textContent = "No files selected";
    return;
  }

  const names = arr.map(f => f.name);
  fileNameDisplay.textContent = names.join(", ");
}

/*
Function to display thumbnail previews of selected image files
Parameters:
- files: FileList | File[]
Returns:
- None
*/
function showImagePreviews(files) {
  previewArea.innerHTML = "";

  const arr = Array.from(files || []);
  if (arr.length === 0) return;

  arr.forEach(file => {
    if (!file.type.startsWith("image/")) return;

    const reader = new FileReader();
    reader.onload = () => {
      const img = document.createElement("img");
      img.src = reader.result;
      img.classList.add("thumbnail");
      previewArea.appendChild(img);
    };
    reader.readAsDataURL(file);
  });

  // Optional single preview (first image)
  if (imagePreview) {
    const first = arr.find(f => f.type.startsWith("image/"));
    if (!first) {
      imagePreview.src = "";
      imagePreview.style.display = "none";
      return;
    }

    const reader = new FileReader();
    reader.onload = e => {
      imagePreview.src = e.target.result;
      imagePreview.style.display = "block";
    };
    reader.readAsDataURL(first);
  }
}

/*
Function to clear the selected files and previews
Parameters:
- None
Returns:
- None
*/
function clearFiles() {
  fileInput.value = "";
  updateFileList([]);
  previewArea.innerHTML = "";
  if (imagePreview) {
    imagePreview.src = "";
    imagePreview.style.display = "none";
  }
}

/* ---------- form validation ---------- */

/*
Function to validate fields and enable / disable analyze button
Parameters:
- None
Returns:
- None
*/
function validateForm() {
  const hasText     = textInput.value.trim().length > 0;
  const hasPlatform = platformSelect.value !== "";

  let inputOk;
  if (inputMode === "url") {
    inputOk = isValidUrl(urlInput ? urlInput.value : "");
  } else {
    const hasImage = fileInput.files.length > 0;
    inputOk = REQUIRE_IMAGE ? hasImage : true;
  }

  analyzeBtn.disabled = !(hasText && hasPlatform && inputOk);
}

/* ---------- API adaptation (v1 backend -> your UI) ---------- */

/*
Function to map backend /v1/analyze response into your UI "result" shape
Parameters:
- apiResult: object
Returns:
- object
*/
function adaptV1ResultToUi(apiResult) {
  // expected: { analysis_id, score, grade, platform, result: { summary, violations, suggestions } }
  const score = Number(apiResult?.score ?? 0);
  const grade = String(apiResult?.grade ?? "").toLowerCase();

  let verdict = "Risky";
  if (grade === "pass") verdict = "Safe";
  else if (grade === "review") verdict = "Borderline";

  const violations = apiResult?.result?.violations ?? [];
  const suggestions = apiResult?.result?.suggestions ?? [];

  // readable violation lines
  // Format a single violation into a readable string
  const fmtViolation = v => {
    const sev  = (v.severity || "medium").toUpperCase();
    const code = v.code || "UNKNOWN";
    const why  = v.rationale || "";
    return `[${sev}] ${code}: ${why}`.trim();
  };

  // Route violations by their source field (text / image / both)
  const textViolations  = sanitizeList(
    violations.filter(v => !v.source || v.source === "text" || v.source === "both").map(fmtViolation)
  );
  const imageViolations = sanitizeList(
    violations.filter(v => v.source === "image" || v.source === "both").map(fmtViolation)
  );

  // Collect suggested fixes per source
  const textFixLines  = [];
  const imageFixLines = [];

  violations.forEach(v => {
    const fix = v.suggested_fix && String(v.suggested_fix).trim();
    if (!fix) return;
    if (v.source === "image") imageFixLines.push(fix);
    else textFixLines.push(fix);
  });

  // Use pre-split suggestions from backend if available, otherwise fall back to flat list
  const result = apiResult?.result ?? {};
  if (result.text_suggestions?.length || result.image_suggestions?.length) {
    (result.text_suggestions  || []).forEach(s => { if (s) textFixLines.push(String(s).trim()); });
    (result.image_suggestions || []).forEach(s => { if (s) imageFixLines.push(String(s).trim()); });
  } else {
    suggestions.forEach(s => { if (s) textFixLines.push(String(s).trim()); });
  }

  return {
    score,
    verdict,
    summary: String(result.summary || ""),
    text_violations:  textViolations,
    image_violations: imageViolations,
    text_suggestions:  sanitizeList(textFixLines),
    image_suggestions: sanitizeList(imageFixLines)
  };
}

/* ---------- popup UI (your existing functions) ---------- */

// Guard flag: only explicit user actions (X button, backdrop click) can close the popup
let _popupIsOpen = false;
let _popupOpenedAt = 0;
let _popupWired = false;

function ensurePopupWiring() {
  if (_popupWired) return;

  const popup = document.getElementById("aiResultPopup");
  const modal = popup ? popup.querySelector(".ai-modal") : null;
  if (!popup || !modal) return;

  // Prevent any click inside the modal card from ever reaching the backdrop
  modal.addEventListener("click", e => e.stopPropagation());

  popup.addEventListener("click", e => {
    // Only a real click on the dark backdrop may close the popup
    if (e.target !== popup) return;

    // Guard against accidental click-through / delayed synthetic clicks right after open
    if (performance.now() - _popupOpenedAt < 350) return;

    closePopup();
  });

  popup.querySelectorAll("[data-popup-close]").forEach(btn => {
    btn.addEventListener("click", e => {
      e.preventDefault();
      e.stopPropagation();
      closePopup(true);
    });
  });

  _popupWired = true;
}

function showPopup(result, apiResult = {}) {
  if (!result || Object.keys(result).length === 0) return;

  ensurePopupWiring();

  const popup = document.getElementById("aiResultPopup");
  // Use direct style override — immune to any class/CSS conflicts
  popup.style.display = "flex";
  popup.classList.remove("hidden");
  popup.classList.add("active");
  _popupIsOpen = true;
  _popupOpenedAt = performance.now();
  document.body.style.overflow = "hidden";

  const score = Number(result.score ?? 0);
  const platform = platformSelect.value || "—";
  const verdict = (result.verdict || "").trim() || verdictFromScore(score);

  const pill = document.getElementById("verdictBadge");
  pill.textContent = verdict;
  pill.className = "verdict-pill " + pillClass(verdict);

  document.getElementById("platformValue").textContent =
    platform.charAt(0).toUpperCase() + platform.slice(1);
  document.getElementById("overallLabel").textContent = labelFromScore(score);

  const summaryEl = document.getElementById("summaryText");
  if (summaryEl) {
    summaryEl.textContent = result.summary || "—";
    const chip = document.getElementById("summaryChip");
    if (chip) chip.style.display = result.summary ? "flex" : "none";
  }

  renderRing(score);

  fillList("textViolations", sanitizeList(result.text_violations));
  fillList("imageViolations", sanitizeList(result.image_violations));
  fillList("textSuggestions", sanitizeList(result.text_suggestions));
  fillList("imageSuggestions", sanitizeList(result.image_suggestions));

  const vCount = sanitizeList(result.text_violations).length +
                 sanitizeList(result.image_violations).length;
  const sCount = sanitizeList(result.text_suggestions).length +
                 sanitizeList(result.image_suggestions).length;
  document.getElementById("violationsCount").textContent = vCount;
  document.getElementById("suggestionsCount").textContent = sCount;

  switchTab("violations");
  document.querySelectorAll(".ai-tab").forEach(btn => {
    btn.onclick = () => switchTab(btn.dataset.tab);
  });

  document.getElementById("copyReportBtn").onclick = () =>
    copyReport({ score, verdict, platform, result });

  document.getElementById("exportPdfBtn").onclick = () =>
    exportToPdf({ score, verdict, platform, result });

  // ── Re-run ────────────────────────────────────────────────────
  const reRunBtn = document.getElementById("reRunBtn");
  if (reRunBtn) {
    reRunBtn.onclick = () => {
      closePopup();
      setTimeout(() => { analyzeBtn.click(); }, 150);
    };
  }

  // ── Feedback (like / dislike) ───────────────────────────────
  const likeBtn    = document.getElementById("feedbackLike");
  const dislikeBtn = document.getElementById("feedbackDislike");

  function resetFeedback() {
    likeBtn.classList.remove("feedback-btn--liked");
    dislikeBtn.classList.remove("feedback-btn--disliked");
  }

  likeBtn.onclick = () => {
    const wasLiked = likeBtn.classList.contains("feedback-btn--liked");
    resetFeedback();
    if (!wasLiked) {
      likeBtn.classList.add("feedback-btn--liked");
      // TODO: POST /v1/feedback { analysis_id, rating: "like" }
    }
  };

  dislikeBtn.onclick = () => {
    const wasDisliked = dislikeBtn.classList.contains("feedback-btn--disliked");
    resetFeedback();
    if (!wasDisliked) {
      dislikeBtn.classList.add("feedback-btn--disliked");
      // TODO: POST /v1/feedback { analysis_id, rating: "dislike" }
    }
  };

  resetFeedback(); // clear state from any previous analysis

  // ── Bookmark (real API) ────────────────────────────────────
  const bookmarkBtn   = document.getElementById("bookmarkBtn");
  const bookmarkLabel = document.getElementById("bookmarkLabel");
  const authToken     = window.TC_AUTH && window.TC_AUTH.getToken();
  const currentId     = apiResult?.analysis_id || null;

  if (!authToken) {
    bookmarkBtn.classList.add("bookmark-btn--locked");
    bookmarkLabel.textContent = "Log in to bookmark";
    bookmarkBtn.onclick = null;
  } else {
    bookmarkBtn.classList.remove("bookmark-btn--locked");
    bookmarkBtn.classList.remove("bookmark-btn--saved");
    bookmarkLabel.textContent = "Bookmark";

    // Check if already bookmarked
    (async () => {
      try {
        const res = await fetch(BOOKMARKS_ENDPOINT, {
          headers: { Authorization: "Bearer " + authToken }
        });
        if (res.ok) {
          const bms = await res.json();
          if (bms.some(b => b.analysis_id === currentId)) {
            bookmarkBtn.classList.add("bookmark-btn--saved");
            bookmarkLabel.textContent = "Bookmarked";
          }
        }
      } catch {}
    })();

    bookmarkBtn.onclick = async () => {
      const isSaved = bookmarkBtn.classList.contains("bookmark-btn--saved");

      if (isSaved) {
        // Remove bookmark
        try {
          await fetch(`${BOOKMARKS_ENDPOINT}/${currentId}`, {
            method: "DELETE",
            headers: { Authorization: "Bearer " + authToken }
          });
          bookmarkBtn.classList.remove("bookmark-btn--saved");
          bookmarkLabel.textContent = "Bookmark";
        } catch { alert("Could not remove bookmark."); }
      } else {
        // Add bookmark
        try {
          const res = await fetch(BOOKMARKS_ENDPOINT, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + authToken
            },
            body: JSON.stringify({
              analysis_id: currentId,
              platform,
              score,
              verdict,
              summary: result.summary || "",
              ad_text: textInput ? textInput.value.trim().slice(0, 200) : "",
            })
          });
          if (res.ok) {
            bookmarkBtn.classList.add("bookmark-btn--saved");
            bookmarkLabel.textContent = "Bookmarked";
          } else if (res.status === 409) {
            bookmarkBtn.classList.add("bookmark-btn--saved");
            bookmarkLabel.textContent = "Bookmarked";
          } else {
            alert("Could not save bookmark.");
          }
        } catch { alert("Could not reach the server."); }
      }
    };
  }
}

function closePopup(force = false) {
  // Guard: only close if popup is actually open
  if (!_popupIsOpen) return;

  // Ignore accidental close attempts immediately after opening unless forced
  if (!force && performance.now() - _popupOpenedAt < 350) return;

  const popup = document.getElementById("aiResultPopup");
  popup.style.display = "none";
  popup.classList.add("hidden");
  popup.classList.remove("active");
  _popupIsOpen = false;
  document.body.style.overflow = "";
}

window.closePopup = closePopup;

function renderRing(score) {
  const fill = document.getElementById("scoreRingFill");
  const valueEl = document.getElementById("scoreValue");
  if (!fill || !valueEl) return;

  const circumference = 314.16;
  const hue = Math.round((score / 100) * 120);
  const color = `hsl(${hue}, 85%, 55%)`;

  fill.style.stroke = color;
  fill.style.strokeDashoffset = circumference - (score / 100) * circumference;

  let current = 0;
  const step = Math.max(1, Math.round(score / 60));
  clearInterval(fill._timer);
  fill._timer = setInterval(() => {
    current = Math.min(current + step, score);
    valueEl.textContent = current;
    if (current >= score) clearInterval(fill._timer);
  }, 16);
}

function switchTab(name) {
  document.querySelectorAll(".ai-tab").forEach(t => {
    t.classList.toggle("ai-tab--active", t.dataset.tab === name);
  });
  document.querySelectorAll(".ai-panel").forEach(p => {
    p.classList.toggle("ai-panel--active", p.id === "panel-" + name);
  });
}

function pillClass(verdict) {
  const v = verdict.toLowerCase();
  if (v.includes("safe") && !v.includes("border")) return "verdict-pill--safe";
  if (v.includes("border")) return "verdict-pill--borderline";
  return "verdict-pill--risky";
}

function fillList(id, arr) {
  const el = document.getElementById(id);
  el.innerHTML = "";

  if (!arr || arr.length === 0) {
    el.innerHTML = `<li class="empty">None</li>`;
    return;
  }

  arr.forEach(item => {
    const li = document.createElement("li");
    li.textContent = item;
    el.appendChild(li);
  });
}

function verdictFromScore(score) {
  if (score >= 80) return "Safe";
  if (score >= 60) return "Borderline";
  return "Risky";
}

function labelFromScore(score) {
  if (score >= 90) return "Very Safe";
  if (score >= 80) return "Safe";
  if (score >= 70) return "Moderate";
  if (score >= 60) return "Borderline";
  return "Risky";
}



function copyReport({ score, verdict, platform, result }) {
  const mk = (title, items) =>
    `${title}\n${(items && items.length) ? items.map(v => `- ${v}`).join("\n") : "- None"}`;

  const text = [
    `Score: ${score}`,
    `Verdict: ${verdict}`,
    `Platform: ${platform}`,
    "",
    mk("Text Violations:", result.text_violations),
    "",
    mk("Image Violations:", result.image_violations),
    "",
    mk("Text Suggestions:", result.text_suggestions),
    "",
    mk("Image Suggestions:", result.image_suggestions),
  ].join("\n");

  navigator.clipboard.writeText(text).then(() => {
    const btn = document.getElementById("copyReportBtn");
    const old = btn.textContent;
    btn.textContent = "Copied!";
    setTimeout(() => (btn.textContent = old), 1000);
  });
}

/* ---------- PDF export ---------- */

function exportToPdf({ score, verdict, platform, result }) {
  if (typeof window.jspdf === "undefined" && typeof window.jsPDF === "undefined") {
    showError("PDF library not loaded. Please check your internet connection.");
    return;
  }

  const { jsPDF } = window.jspdf || window;
  const doc = new jsPDF({ unit: "mm", format: "a4" });

  const W = 210;
  const MARGIN = 18;
  const CONTENT_W = W - MARGIN * 2;
  let y = 0;

  // ── colour helpers ──────────────────────────────────────────
  const BLUE   = [56,  133, 241];
  const GREEN  = [39,  217, 138];
  const YELLOW = [255, 209, 102];
  const RED    = [255, 107, 107];
  const DARK   = [19,  20,  26];
  const MID    = [60,  65,  90];
  const LIGHT  = [140, 148, 180];
  const WHITE  = [255, 255, 255];

  function verdictColor(v) {
    const lv = (v || "").toLowerCase();
    if (lv.includes("safe") && !lv.includes("border")) return GREEN;
    if (lv.includes("border")) return YELLOW;
    return RED;
  }

  function setFill(rgb)   { doc.setFillColor(rgb[0], rgb[1], rgb[2]); }
  function setDraw(rgb)   { doc.setDrawColor(rgb[0], rgb[1], rgb[2]); }
  function setFont(rgb)   { doc.setTextColor(rgb[0], rgb[1], rgb[2]); }

  // ── wrapping helper ─────────────────────────────────────────
  function addWrappedText(text, x, startY, maxW, lineH, maxY) {
    const lines = doc.splitTextToSize(String(text || ""), maxW);
    lines.forEach(line => {
      if (startY > maxY) { doc.addPage(); startY = MARGIN + 10; }
      doc.text(line, x, startY);
      startY += lineH;
    });
    return startY;
  }

  // ── section heading ─────────────────────────────────────────
  function sectionHeading(label, currentY) {
    if (currentY > 265) { doc.addPage(); currentY = MARGIN + 10; }
    doc.setFontSize(9);
    doc.setFont("helvetica", "bold");
    setFont(LIGHT);
    doc.text(label.toUpperCase(), MARGIN, currentY);
    currentY += 1.5;
    setDraw([56, 133, 241]);
    doc.setLineWidth(0.3);
    doc.line(MARGIN, currentY, MARGIN + CONTENT_W, currentY);
    return currentY + 5;
  }

  // ── bullet list ─────────────────────────────────────────────
  function bulletList(items, currentY, color) {
    if (!items || items.length === 0) {
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      setFont(LIGHT);
      doc.text("None", MARGIN + 4, currentY);
      return currentY + 6;
    }
    items.forEach(item => {
      if (currentY > 270) { doc.addPage(); currentY = MARGIN + 10; }
      setFill(color);
      doc.circle(MARGIN + 2, currentY - 1.5, 1, "F");
      doc.setFontSize(9);
      doc.setFont("helvetica", "normal");
      setFont(MID);
      const lines = doc.splitTextToSize(String(item), CONTENT_W - 7);
      lines.forEach((line, i) => {
        if (currentY > 270) { doc.addPage(); currentY = MARGIN + 10; }
        doc.text(line, MARGIN + 6, currentY);
        currentY += 5;
      });
      currentY += 1;
    });
    return currentY;
  }

  // ══ PAGE 1: Header ═══════════════════════════════════════════
  // Background header band
  setFill(DARK);
  doc.rect(0, 0, W, 52, "F");

  // Logo text
  doc.setFontSize(20);
  doc.setFont("helvetica", "bold");
  setFont(WHITE);
  doc.text("TrustCheck", MARGIN, 20);
  doc.setFontSize(20);
  setFont(BLUE);
  doc.text(".AI", MARGIN + doc.getTextWidth("TrustCheck"), 20);

  // Subtitle
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  setFont(LIGHT);
  doc.text("Ad Compliance Analysis Report", MARGIN, 28);

  // Date
  const dateStr = new Date().toLocaleDateString(undefined, { day: "2-digit", month: "long", year: "numeric" });
  doc.text(`Generated: ${dateStr}`, MARGIN, 35);

  // Score circle (right side of header)
  const cx = W - MARGIN - 18, cy = 26, r = 14;
  const hue = Math.round((score / 100) * 120);
  const scoreRgb = score >= 80 ? GREEN : score >= 60 ? YELLOW : RED;

  setDraw(scoreRgb);
  doc.setLineWidth(2.5);
  doc.circle(cx, cy, r, "S");

  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  setFont(scoreRgb);
  const scoreStr = String(score);
  doc.text(scoreStr, cx - doc.getTextWidth(scoreStr) / 2, cy + 2);

  doc.setFontSize(7);
  doc.setFont("helvetica", "normal");
  setFont(LIGHT);
  doc.text("/ 100", cx - doc.getTextWidth("/ 100") / 2, cy + 7);

  y = 60;

  // ── Meta chips row ──────────────────────────────────────────
  const chips = [
    { label: "Platform", value: (platform || "—").charAt(0).toUpperCase() + (platform || "").slice(1) },
    { label: "Verdict",  value: verdict || "—" },
    { label: "Score",    value: `${score} / 100` },
  ];
  const chipW = (CONTENT_W - 8) / 3;
  chips.forEach((chip, i) => {
    const cx2 = MARGIN + i * (chipW + 4);
    setFill([22, 28, 50]);
    setDraw([50, 60, 100]);
    doc.setLineWidth(0.3);
    doc.roundedRect(cx2, y, chipW, 16, 2, 2, "FD");
    doc.setFontSize(7);
    doc.setFont("helvetica", "normal");
    setFont(LIGHT);
    doc.text(chip.label.toUpperCase(), cx2 + 4, y + 5.5);
    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    const vc = chip.label === "Verdict" ? verdictColor(chip.value) : WHITE;
    setFont(vc);
    doc.text(chip.value, cx2 + 4, y + 12);
  });
  y += 24;

  // ── Summary ─────────────────────────────────────────────────
  if (result.summary) {
    y = sectionHeading("Summary", y);
    doc.setFontSize(9.5);
    doc.setFont("helvetica", "normal");
    setFont(MID);
    y = addWrappedText(result.summary, MARGIN, y, CONTENT_W, 5.5, 275);
    y += 6;
  }

  // ── Violations ──────────────────────────────────────────────
  y = sectionHeading("Text Violations", y);
  y = bulletList(result.text_violations, y, RED);
  y += 4;

  y = sectionHeading("Image Violations", y);
  y = bulletList(result.image_violations, y, RED);
  y += 4;

  // ── Suggestions ─────────────────────────────────────────────
  y = sectionHeading("Text Suggestions", y);
  y = bulletList(result.text_suggestions, y, BLUE);
  y += 4;

  y = sectionHeading("Image Suggestions", y);
  y = bulletList(result.image_suggestions, y, BLUE);
  y += 8;

  // ── Footer on every page ────────────────────────────────────
  const pageCount = doc.internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    setFill([18, 20, 30]);
    doc.rect(0, 291, W, 10, "F");
    doc.setFontSize(7.5);
    doc.setFont("helvetica", "normal");
    setFont(LIGHT);
    doc.text("TrustCheck.AI — Powered by Claude AI", MARGIN, 297);
    doc.text(`Page ${i} of ${pageCount}`, W - MARGIN, 297, { align: "right" });
  }

  // ── Save ──────────────────────────────────────────────────────
  const safePlatform = (platform || "report").replace(/[^a-z0-9]/gi, "_");
  const ts = new Date().toISOString().slice(0, 10);
  doc.save(`trustcheck_${safePlatform}_${ts}.pdf`);
}

/* ---------- events ---------- */

dropArea.addEventListener("dragover", e => {
  e.preventDefault();
  dropArea.classList.add("drag-over");
});

dropArea.addEventListener("dragleave", () => {
  dropArea.classList.remove("drag-over");
});

dropArea.addEventListener("drop", e => {
  e.preventDefault();
  dropArea.classList.remove("drag-over");

  const files = e.dataTransfer.files;
  if (files && files.length > 0) {
    setInputFiles(fileInput, files);
    updateFileList(fileInput.files);
    showImagePreviews(fileInput.files);
    validateForm();
  }
});

fileInput.addEventListener("change", () => {
  updateFileList(fileInput.files);
  showImagePreviews(fileInput.files);
  validateForm();
});

deleteBtn.addEventListener("click", e => {
  e.preventDefault();
  clearFiles();
  validateForm();
});

textInput.addEventListener("input", validateForm);
platformSelect.addEventListener("change", validateForm);

analyzeBtn.addEventListener("click", async () => {
  analyzeBtn.disabled = true;
  analyzeBtn.style.display = "none";
  loadingDots.style.display = "flex";

  const description = textInput.value.trim();
  const platform = platformSelect.value;

  try {
    const form = new FormData();
    form.append("platform", platform);
    form.append("language", "auto");
    form.append("ad_text", description);

    if (inputMode === "url") {
      form.append("ad_url", urlInput.value.trim());
    } else {
      Array.from(fileInput.files).forEach(f => form.append("images", f));
    }

    // Attach auth token if the user is logged in
    const authHeaders = {};
    if (window.TC_AUTH && window.TC_AUTH.getToken()) {
      authHeaders["Authorization"] = "Bearer " + window.TC_AUTH.getToken();
    }

    const response = await fetchWithTimeout(ANALYZE_ENDPOINT, {
      method: "POST",
      headers: authHeaders,
      body: form
    }, 45000); // longer timeout for URL fetching

    if (!response.ok) {
      let detail = `Request failed (${response.status})`;
      try {
        const err = await response.json();
        if (response.status === 429 && err?.detail?.message) {
          detail = err.detail.message;
        } else if (err?.detail) {
          detail = typeof err.detail === "string" ? err.detail : JSON.stringify(err.detail);
        }
      } catch {}
      throw new Error(detail);
    }

    const apiResult = await response.json();
    const uiResult = adaptV1ResultToUi(apiResult);

    // Save to localStorage history first (sync, can throw in private browsing)
    try {
      pushHistory({
        timestamp: new Date().toISOString(),
        description,
        platform,
        score: uiResult.score,
        verdict: uiResult.verdict,
        textViolations: uiResult.text_violations,
        imageViolations: uiResult.image_violations,
        textSuggestions: uiResult.text_suggestions,
        imageSuggestions: uiResult.image_suggestions,
        analysisId: apiResult.analysis_id || null
      });
    } catch (_) { /* localStorage unavailable (private mode) — ignore */ }

    // Show result popup — called last so no prior exception can prevent it
    showPopup(uiResult, apiResult);
    updateRateIndicator();
  } catch (err) {
    if (err?.name === "AbortError") {
      showError("Request timed out. Try again.");
    } else {
      showError(err?.message || "Analysis failed. Please try again.");
    }
  } finally {
    analyzeBtn.style.display = "block";
    loadingDots.style.display = "none";
    validateForm();
  }
});

/* ---------- init ---------- */

updateFileList([]);
if (imagePreview) imagePreview.style.display = "none";
validateForm();
updateRateIndicator();
/* ---------- re-run from history ---------- */
(function() {
  const rerun = sessionStorage.getItem("tc_rerun");
  if (!rerun) return;
  sessionStorage.removeItem("tc_rerun");
  try {
    const { text, platform } = JSON.parse(rerun);
    if (text && textInput) textInput.value = text;
    if (platform && platformSelect) {
      platformSelect.value = platform;
    }
    validateForm();
    // Scroll to form
    const form = document.querySelector(".upload-form");
    if (form) form.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch {}
})();

